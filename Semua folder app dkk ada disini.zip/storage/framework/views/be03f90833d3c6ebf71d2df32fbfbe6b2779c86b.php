

<?php $__env->startSection('judul', 'Mobel ledeng'); ?>

<?php $__env->startSection('content'); ?>


<div class="container">
<div class="row">
    <?php $__currentLoopData = $Hero; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $h): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <div class="col-md-4 mt-2">
        <div class="card" style="height:100%;">
            <img src="<?php echo e($h['Image']); ?>" class="card-img-top" alt="Image"> 
            
            <div class="card-body" >
              <p class="card-title" style="font-size:25px;"><?php echo e($h['Name']); ?></p>
              <p class="card-text">Lane : <?php echo e($h['RecLane']); ?></p>

              <?php if($h['Role'] == "Mage"): ?>
                <div class="btn" style="width:fit-content; font-size:20px; color: blue">
                    Mage
                </div>
              <?php elseif($h['Role'] == "Marksman"): ?>
                <div class="btn" style="width:fit-content; font-size:20px; color: #fcf403">
                    Marksman
                </div>
                <?php elseif($h['Role'] == "Tank"): ?>
                <div class="btn" style="width:fit-content; font-size:20px; color : orange">
                    Tank
                </div>
                <?php elseif($h['Role'] == "Support"): ?>
                <div class="btn" style="width:fit-content; font-size:20px; color : #7fffd4">
                    Support
                </div>
                <?php elseif($h['Role'] == "Assassin"): ?>
                <div class="btn" style="width:fit-content; font-size:20px; color : purple">
                    Assassin
                </div>
                <?php else: ?>
                <div class="btn" style="width:fit-content; font-size:20px; color: red">
                    Fighter
                </div>

              <?php endif; ?>
            </div>
        
       </div>
      </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>
</div>   
<?php $__env->stopSection(); ?>
<?php echo $__env->make('background', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Glsc1\resources\views/home.blade.php ENDPATH**/ ?>