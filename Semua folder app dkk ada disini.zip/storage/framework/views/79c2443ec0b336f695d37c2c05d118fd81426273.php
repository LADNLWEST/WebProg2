<div class="container text-center" style="background-color:#000000; height:95px; width:16000px">
    <br>
    <p class="text-white" style="font-size:10px;">Julian Jearsen - 2440112172</p>
    <p class="text-white" style="font-size:10px;">Shanghai MOONTON Technology Co. Ltd </p>
    <p class="text-white" style="font-size:10px;">Copyright ©2022  </p>
    <br>
</div><?php /**PATH C:\xampp\htdocs\Glsc1\resources\views/footer.blade.php ENDPATH**/ ?>