@extends('background')

@section('judul', 'Mobel ledeng')

@section('content')


<div class="container">
<div class="row">
    @foreach($Hero as $h)
      <div class="col-md-4 mt-2">
        <div class="card" style="height:100%;">
            <img src="{{ $h['Image'] }}" class="card-img-top" alt="Image"> 
            
            <div class="card-body" >
              <p class="card-title" style="font-size:25px;">{{$h['Name']}}</p>
              <p class="card-text">Lane : {{$h['RecLane']}}</p>

              @if($h['Role'] == "Mage")
                <div class="btn" style="width:fit-content; font-size:20px; color: blue">
                    Mage
                </div>
              @elseif($h['Role'] == "Marksman")
                <div class="btn" style="width:fit-content; font-size:20px; color: #fcf403">
                    Marksman
                </div>
                @elseif($h['Role'] == "Tank")
                <div class="btn" style="width:fit-content; font-size:20px; color : orange">
                    Tank
                </div>
                @elseif($h['Role'] == "Support")
                <div class="btn" style="width:fit-content; font-size:20px; color : #7fffd4">
                    Support
                </div>
                @elseif($h['Role'] == "Assassin")
                <div class="btn" style="width:fit-content; font-size:20px; color : purple">
                    Assassin
                </div>
                @else
                <div class="btn" style="width:fit-content; font-size:20px; color: red">
                    Fighter
                </div>

              @endif
            </div>
        
       </div>
      </div>
    @endforeach
</div>
</div>   
@endsection